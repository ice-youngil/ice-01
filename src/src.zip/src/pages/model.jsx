import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader';
import axios from 'axios';
import './model.css';

const ModelPopup = ({ onClose }) => {
  const mountRef = useRef(null);

  useEffect(() => {
    let scene, camera, renderer, controls;
    const mount = mountRef.current;

    const fetchModel = async () => {
      try {
        const response = await axios.get('http://localhost:4000/sketchfab-model/1234567890abcdef1234567890abcdef');
        if (response.data.url) {
          console.log('Fetched model URL:', response.data.url); // 모델 URL 확인
          return response.data.url;
        } else {
          throw new Error('Model download URL not found');
        }
      } catch (error) {
        console.error('Error fetching model:', error);
        return null;
      }
    };

    const init = async () => {
      const width = mount.clientWidth;
      const height = mount.clientHeight;

      scene = new THREE.Scene();
      camera = new THREE.PerspectiveCamera(75, width / height, 0.1, 1000);
      camera.position.set(0, 5, 15);

      renderer = new THREE.WebGLRenderer({ antialias: true });
      renderer.setSize(width, height);
      renderer.setPixelRatio(window.devicePixelRatio);
      mount.appendChild(renderer.domElement);

      controls = new OrbitControls(camera, renderer.domElement);
      controls.enableZoom = true;
      controls.minDistance = 3;
      controls.maxDistance = 30;

      const hemiLight = new THREE.HemisphereLight(0xffffff, 0x444444);
      hemiLight.position.set(0, 20, 0);
      scene.add(hemiLight);

      const spotLight = new THREE.SpotLight(0xffffff);
      spotLight.position.set(10, 20, 10);
      spotLight.castShadow = true;
      scene.add(spotLight);

      const modelUrl = await fetchModel();
      if (modelUrl) {
        console.log('Loading model from URL:', modelUrl); // 모델 로드 확인
        const loader = new GLTFLoader();
        loader.load(modelUrl, (gltf) => {
          scene.add(gltf.scene);
        });
      }

      window.addEventListener('resize', onWindowResize, false);
      animate();
    };

    const onWindowResize = () => {
      const width = mount.clientWidth;
      const height = mount.clientHeight;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };

    const animate = () => {
      requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };

    init();

    return () => {
      if (mount) {
        mount.removeChild(renderer.domElement);
      }
      window.removeEventListener('resize', onWindowResize);
    };
  }, []);

  return (
    <div className="model-popup">
      <div className="model-popup-content" ref={mountRef}></div>
      <button className="close-button" onClick={onClose}>Close</button>
    </div>
  );
};

export default ModelPopup;
